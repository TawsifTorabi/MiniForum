<?php
	session_start();
	
	//create database connection
	include("../connect_db.php");
	
	//blank var
	$getsessionID = '';
	
	//call session data
	if(isset($_COOKIE['sessionid'])){
		//get session id from browser and update variable
		$getsessionID = $_COOKIE['sessionid'];
	}
	//set the validity mode for session data
	$validity = "valid";	
	//verify session id
	if(mysqli_num_rows(mysqli_query($con, "select * from sessions where session_id='$getsessionID' AND validity='$validity'"))> 0){

?>
<?php
if(isset($_GET['id'])){
	mysqli_set_charset($con,"utf8");
	$id    		= mysqli_real_escape_string($con, $_GET['id']);
	$sql        = "SELECT * FROM `groups` WHERE `id`=$id";
	$result		= mysqli_query($con, $sql);
	if(!$result){
		echo mysqli_error($con);
	}
	else{
		while($rows=mysqli_fetch_array($result)){
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php echo $rows['name'];?> - About</title>
	<link rel="stylesheet" type="text/css" href="../css/client.css"/>
	<link rel="stylesheet" type="text/css" href="../css/aurna-lightbox.css"/>
	<link rel="stylesheet" href="../css/fontawesome-free-6.2.0-web/css/all.min.css" />
	<style type="text/css" >
	.inputBox {
		padding: 4px;
		width: 300px;
		font-size: 14px;
		color: gray;
		border-radius: 7px;
		border: 1px solid gray;
		background: white;
		margin-bottom: 7px;
	}

	/* CSS */
	.button-15 {
	  background-image: linear-gradient(#42A1EC, #0070C9);
	  border: 1px solid #0077CC;
	  border-radius: 8px;
	  box-sizing: border-box;
	  color: #FFFFFF;
	  cursor: pointer;
	  direction: ltr;
	  display: block;
	  font-family: "SF Pro Text","SF Pro Icons","AOS Icons","Helvetica Neue",Helvetica,Arial,sans-serif;
	  font-size: 19px;
	  font-weight: 400;
	  letter-spacing: 0.08em;
	  line-height: 1.47059;
	  min-width: 30px;
	  overflow: visible;
	  padding: 4px 15px;
	  text-align: center;
	  vertical-align: baseline;
	  user-select: none;
	  -webkit-user-select: none;
	  touch-action: manipulation;
	  white-space: nowrap;
	  width: 250px;
	}

	.button-15:disabled {
	  cursor: default;
	  opacity: .3;
	}

	.button-15:hover {
	  background-image: linear-gradient(#51A9EE, #147BCD);
	  border-color: #1482D0;
	  text-decoration: none;
	}

	.button-15:active {
	  background-image: linear-gradient(#3D94D9, #0067B9);
	  border-color: #006DBC;
	  outline: none;
	}

	.button-15:focus {
	  box-shadow: rgba(131, 192, 253, 0.5) 0 0 0 3px;
	  outline: none;
	}
	#description {
		font-family: arial;
		font-size: 14px;
		resize: none;
		padding: 6px;
		border-radius: 9px;
		border: 3px solid skyblue;
		width: 672px;
		margin-top: 11px;
		margin-bottom: 9px;
		height: 279px;
	}
	</style>
</head>
<body>

	<script src="../js/aurna-lightbox.js"></script>
	<script src="../js/discussion.js"></script>
	<script src="../js/managecontent.js"></script>
	<script src="js/moderator.js"></script>

<ul>
	<li style='background: linear-gradient(to left,#2e76ff, #1abfff);'>
		<a href="javascript:void(0);">
		<?php
			$userid = $_COOKIE['userid'];
			if ($conn->query("SELECT username FROM users WHERE id='$userid'")->num_rows > 0) {
				// output data of each row
				if($row = $conn->query("SELECT username FROM users WHERE id='$userid'")->fetch_assoc()) {
					echo "<span>Hello! <strong>".$row['username']."</strong></span><br>";
				}
			} else {
				echo "<b>Something Went Wrong!</b>";
			}
		?>
		</a>
	</li>
	<li><a href="../index.php">Your Groups</a></li>
	<li><a href="../discover.php">Discover</a></li>
	<li><a href="../creategroup.php">Create New Group</a></li>
	<li class="dropdown">
		<a href="javascript:void(0)" class="dropbtn">Manager</a>
			<div class="dropdown-content">
			  <a href="../manage/groups.php">My Groups</a>
			  <a href="../manage/account.php">My Account</a>
			  <a href="../manage/settings.php">Settings</a>
			</div>
	</li>
	<li style="float:right"><a class="active" href="logout.php">Logout</a></li>
</ul>



<?php 
//Page Header
//Group Cover Photo, Group Name, Group Type, Group Members Count
include("../model/PageHeader.php");
?>


<ul>
	<li><a href="../group.php?id=<?php echo $_GET['id'];?>">About</a></li>
	<li><a href="../discussion.php?id=<?php echo $_GET['id'];?>">Discussion</a></li>
	<li><a href="javascript:void(0);">Topics</a></li>
	<li><a href="../members.php?id=<?php echo $_GET['id'];?>">Members</a></li>
	<li><a href="javascript:void(0);">Events</a></li>
	<li><a href="javascript:void(0);">Media</a></li>
	<li><a href="javascript:void(0);">Files</a></li>
	<li><a href="javascript:void(0);">Chat Rooms</a></li>
	<?php
		include("../model/memberCheck.php");
		if($CurrentUserMod == 1){ 
	?>		
		<li class="activeMenu dropdown modsMenu">
		<a href="javascript:void(0)" class="dropbtn">Manage Group</a>
			<div class="dropdown-content">
			  <a href="posts.php?id=<?php echo $_GET['id'];?>">Manage Posts</a>
			  <a href="comments.php?id=<?php echo $_GET['id'];?>">Manage Comments</a>
			  <a href="#">Approve Members</a>
			  <a href="removemembers.php?id=<?php echo $_GET['id'];?>">Remove Members</a>
			</div>
	</li>
	<?php
		}		
	?>
</ul>

<div class='body' style="width: 90%;">
	<h1>Group Settings</h1>
	<hr>
	<span style="font-size: 20px;">Group Name:</span> <input class="inputBox" type="text" value='<?php echo $rows['name']; ?>' placeholder='You Group Name' name="group_name">
	<button class="button-10" type="submit" value="Save" name="newGroup">Save</button>
	</br>
	<hr>
	<span style="font-size: 18px;">
	Privacy:
	<input type="radio" id="privacy1" name="privacy" value="public">
	<label for="privacy1">Public</label>
	<input type="radio" id="privacy2" name="privacy" value="private">
	<label for="privacy2">Private</label>
	<button class="button-10" type="submit" value="Save" name="newGroup">Save</button><br>
	</span>
	<hr>
	
	<textarea name="description" id="description" placeholder="Type in Description (Limit 1000 Words)">
	<?php echo $rows['about']; ?>
	</textarea>
	</br>
	
	<button class="button-15" type="submit" value="Save" name="newGroup">Save</button>
	</br>
	</br>
	</br>
</div>
	
	
	
</body>
</html>


<?php
		}
	}

 }	}	else { echo "<script>window.open('login.php','_self')</script>"; } ?>
 
 
 
 
 
 
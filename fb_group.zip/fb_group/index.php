<?php
	session_start();
	
	//create database connection
	include("connect_db.php");
	
	//blank var
	$getsessionID = '';
	
	//call session data
	if(isset($_COOKIE['sessionid'])){
		//get session id from browser and update variable
		$getsessionID = $_COOKIE['sessionid'];
	}
	//set the validity mode for session data
	$validity = "valid";	
	//verify session id
	if(mysqli_num_rows(mysqli_query($con, "select * from sessions where session_id='$getsessionID' AND validity='$validity'"))> 0){

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/client.css"/>
	<title>Your Groups</title>
</head>
<body>
<ul>
	<li style='background: linear-gradient(to left,#2e76ff, #1abfff);'>
		<a href="javascript:void(0);">
		<?php
			$userid = $_COOKIE['userid'];
			if ($conn->query("SELECT username FROM users WHERE id='$userid'")->num_rows > 0) {
				// output data of each row
				if($row = $conn->query("SELECT username FROM users WHERE id='$userid'")->fetch_assoc()) {
					echo "<span>Hello! <strong>".$row['username']."</strong></span><br>";
				}
			} else {
				echo "<b>Something Went Wrong!</b>";
			}
		?>
		</a>
	</li>
	<li><a class="activeMenu" href="#">Your Groups</a></li>
	<li><a href="discover.php">Discover</a></li>
	<li><a href="creategroup.php">Create New Group</a></li>
	<li class="dropdown">
		<a href="javascript:void(0)" class="dropbtn">Manager</a>
			<div class="dropdown-content">
			  <a href="myuploads.php">My Uploads</a>
			  <a href="#">My Account</a>
			  <a href="#">Settings</a>
			  <a href="#">Subscription</a>
			</div>
	</li>
	<li style="float:right"><a class="active" href="logout.php">Logout</a></li>
</ul>
<div id='body'>
</br>
		<?php
		$userid = $_COOKIE['userid'];
		if ($conn->query("SELECT name FROM users WHERE id='$userid'")->num_rows > 0) {
			// output data of each row
			if($row = $conn->query("SELECT name FROM users WHERE id='$userid'")->fetch_assoc()) {
				?>
				<div style="margin-left:47px;margin-right: 30%;">
					<div class="typewriter" style="max-width: <?php echo ((strlen($row['name'])*35)+10)?>px;">
					  <h1>Welcome, <?php echo $row['name']; ?></h1>
					</div>
				</div>
				
				<?php
			}
		} else {
			echo "<b style='color:red;'>Authentication Error!</b>";
		}
	?>
	
	<hr style="color:white;">
	
	
	
<div class='mainCont'>
<div id="pageTitle">
	<h1>Your Groups</h1>
	You are member of these Groups
	</br>
	</br>
	<style>
	#tableSearchInput {
		background-color: #eee;
		border: none;
		padding: 9px;
		width: 79%;
		border-bottom: 3px dotted #8a8a8a;
	}
	#tableSearchInput:focus {
		outline: none;
	}
	#tableSearchInputLabel {
		background-color: #bfbfbf;
		border: none;
		padding: 7px;
		width: 20%;
		color: black;
		margin-right: -5px;
		font-family: Trebuchet MS;
		text-transform: uppercase;
		letter-spacing: 0.08em;
		border-bottom: 3px solid #8a8a8a;
		font-weight: bold;
	}
	</style>
	<script>
	function tablesearch() {
	  var input, filter, table, tr, td, i;
	  input = document.getElementById("tableSearchInput");
	  filter = input.value.toUpperCase();
	  table = document.getElementById("dataTable1");
	  tr = table.getElementsByTagName("tr");
	  for (i = 0; i < tr.length; i++) {
		td = tr[i].getElementsByTagName("td")[0];
		if (td) {
		  if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
			tr[i].style.display = "";
		  } else {
			tr[i].style.display = "none";
		  }
		}       
	  }
	}
	</script>
	<div style="width: 890px;"> 
	<span id="tableSearchInputLabel">Search</span>
	<input type="text"  id="tableSearchInput" onkeyup="tablesearch()" placeholder="Filter from Your Groups..."/>
	</div>
</div>
<table border="1" id="dataTable1" style="width: 800px; padding: 20px;">
<?php
	mysqli_set_charset($con,"utf8");
	$id    		= mysqli_real_escape_string($con, $_COOKIE['userid']);
	$sql        = "SELECT * FROM `group_members` WHERE `userid`=$id";
	$result		= mysqli_query($con, $sql);
	$GroupsCount = 0;
	if(!$result){
		echo mysqli_error($con);
	}
	else{
		while($rows=mysqli_fetch_array($result)){
			$GroupsCount++;
			$ambid = $rows['groupID'];
			if($row=mysqli_fetch_array(mysqli_query($con, "SELECT id,name,type FROM `groups` Where id=$ambid"), MYSQLI_ASSOC)){
	?>		
				<tr class="hoverROw">
					<td id="col1"><a style="color: white;" href="group.php?id=<?php echo $row['id']?>"><?php echo $row['name']?></a></td>
					<td id="col2"><?php echo $row['type']?> Group</td>
				</tr>
	<?php
			}
		}
		if($GroupsCount == 0){
			?>
			<center>
			<h1>Oh! You got no groups 😥</h1>
			<a href='discover.php'><h3>Try Discover a group for you.</h3></a>
			<a href='creategroup.php'><h3>Or just create one with friends.</h3></a>
			<script>document.getElementById('pageTitle').style.display='none';</script>
			<?php
		}
	}

?>
</table>
	
</div>
</div>
</body>
</html>


<?php 	}	else { echo "<script>window.open('login.php','_self')</script>"; } ?>
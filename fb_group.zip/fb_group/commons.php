<?php
	$GlobalAppName = 'Facebook Groups';
	$rootdir = 'fb_group';
	$ShowContent = 0;
	$CurrentUserMember = 0;
	$CurrentUserOwner = 0;
	$CurrentUserMod = 0;
?>
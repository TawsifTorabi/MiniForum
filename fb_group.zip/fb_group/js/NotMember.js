	String.prototype.isMatch = function(s){
	   return this.match(s)!==null
	}

	function JoinGroup(groupid){
		let BtnCont = 'joinnbtn';
		document.getElementById(BtnCont).setAttribute("disabled","true");;
		let	xmlhttp=new XMLHttpRequest();
		xmlhttp.onreadystatechange=function() {
			if(this.readyState == 4 && this.status == 200) {
				document.getElementById(BtnCont).disabled='true';
				console.log(this.responseText);
				
				let RetJson = JSON.parse(this.responseText);
				
				if(RetJson.RequestSent.isMatch('true')){
					document.getElementById(BtnCont).innerHTML='<i class="fa-solid fa-check"></i> Request Sent!';
					setTimeout(function(){
						document.getElementById(BtnCont).innerHTML='<i class="fa-solid fa-times"></i> Cancel Request';
						document.getElementById(BtnCont).removeAttribute("disabled");;
					}, 3000);
				}


				if(RetJson.RequestCanceled.isMatch('true')){
					document.getElementById(BtnCont).innerHTML='<i class="fa-solid fa-check"></i> Request Canceled!';
					setTimeout(function(){
						document.getElementById(BtnCont).innerHTML='<i class="fa-solid fa-plus"></i> Join Group';
						document.getElementById(BtnCont).removeAttribute("disabled");
					}, 3000);
				}
				
				
			}else{
				
			}
		}
		xmlhttp.open("GET","ajax.php?data=JoinGroup&id="+groupid, true);
		xmlhttp.send();		
	}
	
	
	function CopyGroupLink1(){
		navigator.clipboard.writeText(location.href);
		document.getElementById('shareBtn1').innerHTML = '<i class="fa-solid fa-check"></i> URL Copied! ';	
		setTimeout(function(){
			document.getElementById('shareBtn1').innerHTML='<i class="fa-solid fa-copy"></i> Copy Group URL';
		}, 3000);
	}

	function LeaveGroup(groupid){
		let BtnCont = 'leavebtn';
		document.getElementById(BtnCont).setAttribute("disabled","true");;
		document.getElementById(BtnCont).innerHTML='Leaving Group...';
		let	xmlhttp=new XMLHttpRequest();
		xmlhttp.onreadystatechange=function() {
			if(this.readyState == 4 && this.status == 200) {
				document.getElementById(BtnCont).disabled='true';
				console.log(this.responseText);
				
				let RetJson = JSON.parse(this.responseText);
				
				if(RetJson.groupLeaved.isMatch('true')){
					document.getElementById(BtnCont).innerHTML='<i class="fa-solid fa-check"></i> Group Left';
					setTimeout(function(){
						window.location.href = "index.php";
					}, 1000);
				}
				
			}else{
				
			}
		}
		xmlhttp.open("GET","ajax.php?data=LeaveGroup&id="+groupid, true);
		xmlhttp.send();		
	}
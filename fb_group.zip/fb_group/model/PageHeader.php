<!--script src="js/NotMember.js"></script-->
<script>
String.prototype.isMatch = function(s){
	   return this.match(s)!==null
	}

	function JoinGroup(groupid){
		let BtnCont = 'joinnbtn';
		document.getElementById(BtnCont).setAttribute("disabled","true");;
		let	xmlhttp=new XMLHttpRequest();
		xmlhttp.onreadystatechange=function() {
			if(this.readyState == 4 && this.status == 200) {
				document.getElementById(BtnCont).disabled='true';
				console.log(this.responseText);
				
				let RetJson = JSON.parse(this.responseText);
				
				if(RetJson.RequestSent.isMatch('true')){
					document.getElementById(BtnCont).innerHTML='<i class="fa-solid fa-check"></i> Request Sent!';
					setTimeout(function(){
						document.getElementById(BtnCont).innerHTML='<i class="fa-solid fa-times"></i> Cancel Request';
						document.getElementById(BtnCont).removeAttribute("disabled");;
					}, 3000);
				}


				if(RetJson.RequestCanceled.isMatch('true')){
					document.getElementById(BtnCont).innerHTML='<i class="fa-solid fa-check"></i> Request Canceled!';
					setTimeout(function(){
						document.getElementById(BtnCont).innerHTML='<i class="fa-solid fa-plus"></i> Join Group';
						document.getElementById(BtnCont).removeAttribute("disabled");
					}, 3000);
				}
				
				
			}else{
				
			}
		}
		xmlhttp.open("GET","ajax.php?data=JoinGroup&id="+groupid, true);
		xmlhttp.send();		
	}
	
	
	function CopyGroupLink1(){
		navigator.clipboard.writeText(location.href);
		document.getElementById('shareBtn1').innerHTML = '<i class="fa-solid fa-check"></i> URL Copied! ';	
		setTimeout(function(){
			document.getElementById('shareBtn1').innerHTML='<i class="fa-solid fa-copy"></i> Copy Group URL';
		}, 3000);
	}

	function LeaveGroup(groupid){
		let BtnCont = 'leavebtn';
		document.getElementById(BtnCont).setAttribute("disabled","true");;
		document.getElementById(BtnCont).innerHTML='Leaving Group...';
		let	xmlhttp=new XMLHttpRequest();
		xmlhttp.onreadystatechange=function() {
			if(this.readyState == 4 && this.status == 200) {
				document.getElementById(BtnCont).disabled='true';
				console.log(this.responseText);
				
				let RetJson = JSON.parse(this.responseText);
				
				if(RetJson.groupLeaved.isMatch('true')){
					document.getElementById(BtnCont).innerHTML='<i class="fa-solid fa-check"></i> Group Left';
					setTimeout(function(){
						window.location.href = "index.php";
					}, 1000);
				}
				
			}else{
				
			}
		}
		xmlhttp.open("GET","ajax.php?data=LeaveGroup&id="+groupid, true);
		xmlhttp.send();		
	}
</script>
<div class="pageHeader" style="background-image: linear-gradient(to bottom, transparent, black), url(/<?php echo $rootdir; ?>/uploads/<?php echo $rows['coverimg']; ?>);">
	<div class="pageHeaderCont">
	<h1 style="font-size: 35px;"><?php echo $rows['name'];?></h1>
	<?php if($rows['type'] == 'private'){echo'Private';}else{echo'Public';}?> Group . 
	<a href="members.php?id=<?php echo $id; ?>">
	<?php 
		$MembersRowCounter = mysqli_num_rows( mysqli_query($con, "SELECT * FROM `group_members` WHERE `groupID`=$id"));
		if($MembersRowCounter){
			echo $MembersRowCounter." Members";
		}else{
			 echo "No Members!";
		}
	?>
	</a>
	<?php
	if($ShowContent == 1){
	?>
		&nbsp;
		<button class="button-10" id="shareBtn1" onclick="CopyGroupLink1()"><i class="fa-solid fa-copy"></i> Copy Group URL</button>
		&nbsp;
		<?php if($CurrentUserMember == 1 && $CurrentUserOwner == 0){?>
		<button class="button-11" id="leavebtn" onclick="LeaveGroup(<?php echo $id; ?>)">Leave Group</button></br>	
		<?php } ?>
		
		
		
		<?php if($CurrentUserMember == 0){
			$groupIDSelec1    	= mysqli_real_escape_string($con, $_GET['id']);
			$userIDSlec1		= $_COOKIE['userid'];
		   // it return number of rows in the table.
			$JoinRequestRow = mysqli_num_rows(mysqli_query($con, "SELECT * FROM `join_requests` WHERE `groupID`='$groupIDSelec1' AND `userID`='$userIDSlec1'"));
			if($JoinRequestRow >= 1){
		?>
			<button style="width: 190px;" class="button-10" id="joinnbtn" onclick="JoinGroup(<?php echo $_GET['id']; ?>)"><i class="fa-solid fa-times"></i> Cancel Request</button>
			
		<?php
				} else if($JoinRequestRow == 0){
		?>
			<button style="width: 190px;" class="button-10" id="joinnbtn" onclick="JoinGroup(<?php echo $_GET['id']; ?>)"><i class="fa-solid fa-plus"></i> Join Group</button>
		<?php
				}

		?>
		<?php } 
	} ?>
	</div>
	
</div>
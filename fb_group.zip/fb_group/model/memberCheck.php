<?php
		//Member Verification, Show Content if User is Member
		//For General User
		$CurrentUserId = $_COOKIE['userid'];
		$memresult1 = mysqli_num_rows(mysqli_query($con, "SELECT * FROM `group_members` WHERE `userID`=".$CurrentUserId." AND `groupID`=$id"));
		$Ownerresult1 = mysqli_num_rows(mysqli_query($con, "SELECT * FROM `groups` WHERE `ownerID`=".$CurrentUserId." AND `id`=$id"));
		$modresult1 = mysqli_num_rows(mysqli_query($con, "SELECT * FROM `group_moderators` WHERE `userID`=".$CurrentUserId." AND `groupID`=$id"));


		if(isset($rows['type'])){
			
			if($rows['type'] == 'private'){
				if($memresult1 == 1){
					$ShowContent = 1;
					$CurrentUserMember = 1;
				}else{
					$ShowContent = 0;
					$CurrentUserMember = 0;
				}
			}
			

			if($rows['type'] == 'public'){				
				if($memresult1 == 1){ 
					$ShowContent = 1;
					$CurrentUserMember = 1;
				}else{
					$ShowContent = 1;
					$CurrentUserMember = 0;
				}
			}
			
		}

			if(!$Ownerresult1){
				echo mysqli_error($con);
			}else{
				if($Ownerresult1 == 1){ 
						$CurrentUserOwner = 1;
						$CurrentUserMod = 1;
						$ShowContent = 1;
				}else{
						$CurrentUserOwner = 0;
				}
			}

		//For Moderator
		
		if(!$modresult1){
			echo mysqli_error($con);
		}else{
			if($modresult1 == 1){
				$CurrentUserMod = 1;
				$ShowContent = 1;
			}
			if($modresult1 == 0){
				$CurrentUserMod = 0;
			}
		}
	
?>
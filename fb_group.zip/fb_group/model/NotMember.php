	<?php include("PageHeader.php"); ?>
	<div style="margin-left: 82px;">
	</br>
	<h1>You are not a member!</h1>
	<h3>You need a invitation to join this Group.</h3>

<?php				

	$groupIDSelec1    	= mysqli_real_escape_string($con, $_GET['id']);
	$userIDSlec1		= $_COOKIE['userid'];
   // it return number of rows in the table.
	$JoinRequestRow = mysqli_num_rows(mysqli_query($con, "SELECT * FROM `join_requests` WHERE `groupID`='$groupIDSelec1' AND `userID`='$userIDSlec1'"));
	if($JoinRequestRow >= 1){
?>
	<button style="width: 190px;" class="button-10" id="joinnbtn" onclick="JoinGroup(<?php echo $_GET['id']; ?>)"><i class="fa-solid fa-times"></i> Cancel Request</button>
	
<?php
		} else if($JoinRequestRow == 0){
?>
	<button style="width: 190px;" class="button-10" id="joinnbtn" onclick="JoinGroup(<?php echo $_GET['id']; ?>)"><i class="fa-solid fa-plus"></i> Join Group</button>
<?php
		}

?>	
	
	</div>

<?php
	session_start();
	
	//create database connection
	include("connect_db.php");
	
	//blank var
	$getsessionID = '';
	
	//call session data
	if(isset($_COOKIE['sessionid'])){
		//get session id from browser and update variable
		$getsessionID = $_COOKIE['sessionid'];
	}
	//set the validity mode for session data
	$validity = "valid";	
	//verify session id
	if(mysqli_num_rows(mysqli_query($con, "select * from sessions where session_id='$getsessionID' AND validity='$validity'"))> 0){

				
				if(isset($_POST['newGroup'])){

					$imgArr = array("bg5.jpg","bg1.jpg","bg3.jpg");
					shuffle($imgArr);
									
					$group_name = mysqli_real_escape_string($con, $_POST["group_name"]);
					$description = mysqli_real_escape_string($con, $_POST["description"]);
					$type = mysqli_real_escape_string($con, $_POST["privacy"]);
					$coverimg = $imgArr[0];
					$ownerID = $_COOKIE['userid'];
					
					if($type == "private"){
						$type = "private";
					}else{
						$type == "public";
					}
					
					if(mysqli_query($con, "Insert Into `groups` Values (DEFAULT,'$group_name','$type','$description','$coverimg','$ownerID')")){
						$last_id = mysqli_insert_id($con);
						mysqli_query($con, "Insert Into `group_members` Values (DEFAULT,'$last_id','$ownerID','1')");	  
					}


					echo "<script>window.open('group.php?id=".$last_id."','_self')</script>";
					//echo mysql_error();
							

				}
		
			?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/client.css"/>
	<title>Create New Groups</title>
</head>
<body>
<ul>
	<li style='background: linear-gradient(to left,#2e76ff, #1abfff);'>
		<a href="javascript:void(0);">
		<?php
			$userid = $_COOKIE['userid'];
			if ($conn->query("SELECT username FROM users WHERE id='$userid'")->num_rows > 0) {
				// output data of each row
				if($row = $conn->query("SELECT username FROM users WHERE id='$userid'")->fetch_assoc()) {
					echo "<span>Hello! <strong>".$row['username']."</strong></span><br>";
				}
			} else {
				echo "<b>Something Went Wrong!</b>";
			}
		?>
		</a>
	</li>
	<li><a href="index.php">Your Groups</a></li>
	<li><a href="discover.php">Discover</a></li>
	<li><a class="activeMenu" href="#">Create New Group</a></li>
	<li class="dropdown">
		<a href="javascript:void(0)" class="dropbtn">Manager</a>
			<div class="dropdown-content">
			  <a href="manage/groups.php">My Groups</a>
			  <a href="manage/account.php">My Account</a>
			  <a href="manage/settings.php">Settings</a>
			</div>
	</li>
	<li style="float:right"><a class="active" href="logout.php">Logout</a></li>
</ul>
<div id='body'>
</br>
		<?php
		$userid = $_COOKIE['userid'];
		if ($conn->query("SELECT name FROM users WHERE id='$userid'")->num_rows > 0) {
			// output data of each row
			if($row = $conn->query("SELECT name FROM users WHERE id='$userid'")->fetch_assoc()) {
				?>
				<div style="margin-left:47px;margin-right: 30%;">
					<div class="typewriter" style="max-width: <?php echo (strlen($row['name'])*32)?>px;">
					  <h1>Welcome, <?php echo $row['name']; ?></h1>
					</div>
				</div>
				
				<?php
			}
		} else {
			echo "<b style='color:red;'>Authentication Error!</b>";
		}
	?>
	
	<hr style="color:white;">
	
	
	
<div class='mainCont'>
<h1>Create New Group!</h1>
<style type="text/css" >
	.inputBox{
	  padding: 11px;
	  width: 250px;
	  font-size: 18px;
	  color: gray;
	  border-radius: 7px;
	  border: 1px solid gray;
	  background: white;
	  margin-bottom: 7px;
	}

	/* CSS */
	.button-15 {
	  background-image: linear-gradient(#42A1EC, #0070C9);
	  border: 1px solid #0077CC;
	  border-radius: 8px;
	  box-sizing: border-box;
	  color: #FFFFFF;
	  cursor: pointer;
	  direction: ltr;
	  display: block;
	  font-family: "SF Pro Text","SF Pro Icons","AOS Icons","Helvetica Neue",Helvetica,Arial,sans-serif;
	  font-size: 19px;
	  font-weight: 400;
	  letter-spacing: 0.08em;
	  line-height: 1.47059;
	  min-width: 30px;
	  overflow: visible;
	  padding: 4px 15px;
	  text-align: center;
	  vertical-align: baseline;
	  user-select: none;
	  -webkit-user-select: none;
	  touch-action: manipulation;
	  white-space: nowrap;
	  width: 250px;
	}

	.button-15:disabled {
	  cursor: default;
	  opacity: .3;
	}

	.button-15:hover {
	  background-image: linear-gradient(#51A9EE, #147BCD);
	  border-color: #1482D0;
	  text-decoration: none;
	}

	.button-15:active {
	  background-image: linear-gradient(#3D94D9, #0067B9);
	  border-color: #006DBC;
	  outline: none;
	}

	.button-15:focus {
	  box-shadow: rgba(131, 192, 253, 0.5) 0 0 0 3px;
	  outline: none;
	}
	#description {
		font-family: arial;
		font-size: 14px;
		resize: none;
		padding: 6px;
		border-radius: 9px;
		border: 3px solid skyblue;
		width: 672px;
		margin-top: 11px;
		margin-bottom: 9px;
		height: 279px;
	}
</style>
<form  method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
	<input class="inputBox" type="text" placeholder="Group Name" name="group_name">
	</br>
	<span style="font-size: 18px;">
	Privacy:
	<input type="radio" id="privacy1" name="privacy" value="public">
	<label for="privacy1">Public</label>
	<input type="radio" id="privacy2" name="privacy" value="private">
	<label for="privacy2">Private</label><br>
	</span>
	<textarea name="description" id="description" placeholder="Type in Description (Limit 1000 Words)"></textarea>
	</br>
	<input class="button-15" type="submit" value="Create New Group" name="newGroup">
</form>
</div>
</div>
</body>
</html>


<?php 	}	else { echo "<script>window.open('login.php','_self')</script>"; } ?>
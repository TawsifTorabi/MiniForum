String.prototype.isMatch = function(s){
   return this.match(s)!==null
}


function DeletePostMods(postid, groupID){
	if(confirm('Are You Sure want to Delete this post?') == true){
		var PostContainer = 'postRow'+postid;
		xmlhttp=new XMLHttpRequest();
		xmlhttp.onreadystatechange=function() {
			if(this.readyState == 4 && this.status == 200) {
				console.log(this.responseText);
				var RetJson = JSON.parse(this.responseText);
				if(RetJson.deleted.isMatch('true')){
					document.getElementById(PostContainer).remove();
				}
			}
		}
		xmlhttp.open("GET","adminAjax.php?data=deletePost&post_id="+postid+"&group_id="+groupID, true);
		xmlhttp.send();		
	}
}


function MemberApprove(id, groupid, Opstype){
	let BtnCont = 'postRow'+id;
	let AprBtn = 'AprBtn'+id;
	let DecBtn = 'DecBtn'+id;
	
	document.getElementById(AprBtn).setAttribute("disabled","true");
	document.getElementById(DecBtn).setAttribute("disabled","true");
	
	
	var	xmlhttp=new XMLHttpRequest();
	
	if(Opstype == 'true'){
			xmlhttp.onreadystatechange=function() {
			if(this.readyState == 4 && this.status == 200) {
				console.log(this.responseText);
				let RetJson = JSON.parse(this.responseText);
				if(RetJson.approved.isMatch('true')){
					document.getElementById(DecBtn).removeAttribute("disabled");
					document.getElementById(AprBtn).innerHTML='<i class="fa-solid fa-check"></i> Approved!';
					setTimeout(function(){
						document.getElementById(BtnCont).remove();
					}, 500);
				}
			}
			};
	}
	
	if(Opstype == 'false'){
			xmlhttp.onreadystatechange=function() {
			if(this.readyState == 4 && this.status == 200) {
				
				console.log(this.responseText);
				let RetJson = JSON.parse(this.responseText);
				if(RetJson.deleted.isMatch('true')){
					document.getElementById(DecBtn).removeAttribute("disabled");
					document.getElementById(DecBtn).innerHTML='<i class="fa-solid fa-check"></i> Declined!';
					setTimeout(function(){
						document.getElementById(BtnCont).remove();
					}, 500);
				}
				
				
			}
			};
	}
	
	xmlhttp.open("GET","adminAjax.php?data=ApproveMember&group_id="+groupid+"&id="+id+"&bool="+Opstype, true);
	xmlhttp.send();
	
}	





function DeclineMember(userID, groupID){
	if(confirm('Are You Sure want to Delete this post?') == true){
		var PostContainer = 'postRow'+postid;
		xmlhttp=new XMLHttpRequest();
		xmlhttp.onreadystatechange=function() {
			if(this.readyState == 4 && this.status == 200) {
				console.log(this.responseText);
				var RetJson = JSON.parse(this.responseText);
				if(RetJson.deleted.isMatch('true')){
					document.getElementById(PostContainer).remove();
				}
			}
		}
		xmlhttp.open("GET","adminAjax.php?data=deletePost&post_id="+postid+"&group_id="+groupID, true);
		xmlhttp.send();		
	}
}
	
	
	

	
	
